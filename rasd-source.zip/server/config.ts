import dotenv from 'dotenv';
export function loadEnvironment() {
  dotenv.config({ path: ['.env.local', '.env'], override: false, quiet: true });
}
export function credentialStatus() {
  return Object.fromEntries(
    ['OPENAI_API_KEY', 'TAVILY_API_KEY'].map((name) => {
      const value = process.env[name]?.trim();
      return [
        name,
        !!value && !/^(your[-_ ]|replace|changeme|example|test-only|sk-\.\.\.)/i.test(value),
      ];
    }),
  ) as Record<'OPENAI_API_KEY' | 'TAVILY_API_KEY', boolean>;
}
