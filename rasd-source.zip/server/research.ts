export interface Evidence {
  title: string;
  url: string;
  finding: string;
  field: string;
  applied: boolean;
  classification: 'source' | 'estimate' | 'conversion';
}
export interface Research {
  status: 'available' | 'unconfigured' | 'unavailable' | 'not-needed';
  evidence: Evidence[];
  warning?: string;
}
const cache = new Map<string, { expires: number; result: Research }>();
export function relevant(source: { title: string; content: string; url: string }, topic: string) {
  let url;
  try {
    url = new URL(source.url);
  } catch {
    return false;
  }
  if (url.protocol !== 'https:') return false;
  const text = (source.title + ' ' + source.content).toLowerCase();
  const terms: Record<string, RegExp> = {
    salary: /salary|salaries|compensation|راتب|رواتب|أجور/,
    price: /price|pricing|سعر|أسعار|تكلفة/,
    tax: /vat|value.added.tax|ضريبة|قيمة مضافة/,
  };
  return (terms[topic] ?? /$a/).test(text) && /saudi|السعودية|سعودي|\bSAR\b/i.test(text);
}
export async function research(
  topic: 'salary' | 'price' | 'tax',
  field: string,
  context: string,
): Promise<Research> {
  const key = JSON.stringify([topic, field, context]);
  const existing = cache.get(key);
  if (existing && existing.expires > Date.now()) return existing.result;
  if (!process.env.TAVILY_API_KEY)
    return {
      status: 'unconfigured',
      evidence: [],
      warning:
        'البحث المباشر غير مهيأ: أضف TAVILY_API_KEY. القيم الاقتصادية تقديرات ولا تمثل مصادر موثقة.',
    };
  try {
    const response = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: process.env.TAVILY_API_KEY,
        query: `Saudi Arabia ${topic} ${context.slice(0, 200)}`,
        max_results: 5,
        search_depth: 'basic',
        include_answer: false,
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!response.ok) throw Error();
    const body = (await response.json()) as any;
    const evidence: Evidence[] = (body.results ?? [])
      .filter(
        (s: any) =>
          typeof s.title === 'string' &&
          typeof s.content === 'string' &&
          typeof s.url === 'string' &&
          relevant(s, topic),
      )
      .map((s: any) => ({
        title: s.title.slice(0, 200),
        url: s.url,
        finding: s.content.slice(0, 800),
        field,
        applied: false,
        classification: 'source',
      }));
    const result: Research = {
      status: 'available',
      evidence,
      ...(!evidence.length
        ? { warning: 'لم يعثر على دليل ذي صلة كافٍ. لن تعتمد قواعد رقمية من نتائج غير متحققة.' }
        : {
            warning:
              'مصادر ذات صلة للمراجعة؛ لا تستخرج حدوداً رقمية آلياً دون تحقق. تقديرات التوليد مستقلة عن هذه المصادر.',
          }),
    };
    if (cache.size > 200) cache.delete(cache.keys().next().value!);
    cache.set(key, { expires: Date.now() + 3600000, result });
    return result;
  } catch {
    return {
      status: 'unavailable',
      evidence: [],
      warning: 'تعذر الاتصال بخدمة البحث؛ لم يطبق أي مصدر خارجي.',
    };
  }
}
