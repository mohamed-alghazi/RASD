import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  ArrowUpLeft,
  ArrowUp,
  ArrowLeft,
  Braces,
  Database,
  Globe2,
  MessageSquare,
  Plus,
  ShieldCheck,
  Sparkles,
  Zap,
  Menu,
  X,
  Layers,
  Check,
  ChevronLeft,
  History,
} from 'lucide-react';
import type { Plan } from '../shared/schema';
import { api, post } from './api';
import { Busy, Disclosure, ErrorBox, JobResult, PlanView, Upload, Downloads } from './components';
import './style.css';
import '@fontsource/ibm-plex-sans-arabic/400.css';
import '@fontsource/ibm-plex-sans-arabic/500.css';
import '@fontsource/ibm-plex-sans-arabic/600.css';
import '@fontsource/ibm-plex-sans-arabic/700.css';
type Service = 'home' | 'chat' | 'quick' | 'localize' | 'downloads';
const services = [
  {
    key: 'chat' as Service,
    n: '01',
    icon: MessageSquare,
    title: 'التوليد بالمحادثة',
    en: 'AI CONVERSATION',
    description: 'صف فكرتك. ودع رصد يحوّلها إلى جداول مترابطة، وبيانات تفهم سياق مشروعك.',
    tag: 'من الفكرة إلى البيانات',
  },
  {
    key: 'quick' as Service,
    n: '02',
    icon: Zap,
    title: 'التوليد السريع',
    en: 'SCHEMA TO DATA',
    description: 'مخطط قاعدة بياناتك هو نقطة البداية. ارفعه، راجع الخطة، واحصل على بيانات جاهزة.',
    tag: 'متوافق مع مخططك',
  },
  {
    key: 'localize' as Service,
    n: '03',
    icon: Globe2,
    title: 'التوطين السعودي',
    en: 'MADE FOR SAUDI',
    description: 'امنح بياناتك سياقاً سعودياً. أسماء، مدن، وقيم اقتصادية مع حفظ العلاقات.',
    tag: 'سياق محلي، دقة أعلى',
  },
];
function App() {
  const [page, setPage] = useState<Service>('home'),
    [menu, setMenu] = useState(false),
    [health, setHealth] = useState<any>(null);
  useEffect(() => {
    api('/health')
      .then(setHealth)
      .catch(() => {});
  }, []);
  function navigate(s: Service) {
    setPage(s);
    setMenu(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  return (
    <div className="app">
      <header className="site-header">
        <button className="brand" aria-label="رصد الرئيسية" onClick={() => navigate('home')}>
          <span className="brand-icon">
            <span />
            <span />
            <span />
          </span>
          <b>
            رصد<span>RASD</span>
          </b>
        </button>
        <nav className={menu ? 'open' : ''}>
          <button className={page === 'home' ? 'selected' : ''} onClick={() => navigate('home')}>
            الرئيسية
          </button>
          {services.map((s) => (
            <button
              key={s.key}
              className={page === s.key ? 'selected' : ''}
              onClick={() => navigate(s.key)}
            >
              {s.title}
            </button>
          ))}
        </nav>
        <div className="header-end">
          <button className="text-button" onClick={() => navigate('downloads')}>
            <History size={15} />
            تنزيلاتي
          </button>
          <span className="saudi-dot" /> صُنع للسياق السعودي{' '}
          <button className="menu-button" aria-label="القائمة" onClick={() => setMenu(!menu)}>
            {menu ? <X /> : <Menu />}
          </button>
        </div>
      </header>
      {page === 'home' ? (
        <Home onNavigate={navigate} />
      ) : (
        <main className="workspace">
          <div className="workspace-top">
            <button className="text-button" onClick={() => navigate('home')}>
              الرئيسية <ChevronLeft size={14} />
            </button>
            <span>{services.find((s) => s.key === page)?.title}</span>
            <span className="workspace-status">
              <span /> مساحة عمل آمنة
            </span>
          </div>
          <div className="workspace-heading">
            <span className="eyebrow">{services.find((s) => s.key === page)?.en}</span>
            <h1>{services.find((s) => s.key === page)?.title ?? 'تنزيلاتي'}</h1>
            <p>
              {page === 'chat'
                ? 'حوار بسيط. خطة واضحة. بيانات مترابطة بعد اعتمادك.'
                : page === 'quick'
                  ? 'ابدأ من البنية التي بنيتها. حافظ على مفاتيحك وقيودك.'
                  : page === 'downloads'
                    ? 'استرجع مهام هذا المتصفح، وافحص النتائج أو نزّلها قبل انتهاء صلاحيتها.'
                    : 'بياناتك نفسها، بسياق أقرب. تبقى المفاتيح والعلاقات محفوظة.'}
            </p>
          </div>
          {page === 'chat' ? (
            <Chat key="chat" configured={health?.aiConfigured} />
          ) : page === 'quick' ? (
            <Quick />
          ) : page === 'localize' ? (
            <Localization />
          ) : (
            <Downloads />
          )}
        </main>
      )}
      <footer>
        <div className="footer-brand">
          رصد <span>بيانات تفهم مشروعك.</span>
        </div>
        <span>بيانات اصطناعية · خصوصية أولاً · سياق سعودي</span>
        <small>RASD © {new Date().getFullYear()}</small>
      </footer>
    </div>
  );
}
function Home({ onNavigate }: { onNavigate: (s: Service) => void }) {
  return (
    <main>
      <section className="hero">
        <div className="hero-grid" />
        <div className="hero-copy">
          <div className="hero-badge">
            <span /> بيانات اصطناعية. واقعية بلا تعقيد.
          </div>
          <h1>
            مشروعك يستحق
            <br />
            بيانات <em>تفهمه.</em>
          </h1>
          <p>
            من فكرتك إلى قاعدة بيانات تنبض بالواقع.
            <br />
            ولّد بيانات مترابطة، دقيقة، ومصممة للسياق السعودي.
          </p>
          <div className="hero-actions">
            <button className="primary large" onClick={() => onNavigate('chat')}>
              ابدأ بالمحادثة <ArrowUpLeft size={19} />
            </button>
            <button className="secondary large" onClick={() => onNavigate('quick')}>
              <Braces size={19} /> لديّ مخطط جاهز
            </button>
          </div>
          <div className="hero-notes">
            <span>
              <Check size={15} /> علاقات صحيحة
            </span>
            <span>
              <Check size={15} /> توليد قابل للتكرار
            </span>
            <span>
              <Check size={15} /> بياناتك في أمان
            </span>
          </div>
        </div>
        <div className="hero-art" aria-label="رسم توضيحي لجداول مترابطة">
          <div className="orbit orbit-one" />
          <div className="orbit orbit-two" />
          <div className="floating-tag">
            <span /> العلاقات متسقة
          </div>
          <div className="diagram-line line-one" />
          <div className="diagram-line line-two" />
          <div className="mini-table table-company">
            <div>
              <Database size={14} />
              <code>companies</code>
              <span>01</span>
            </div>
            <p>
              <i>PK</i>
              <code>id</code>
              <b>1</b>
            </p>
            <p>
              <code>name</code>
              <b>شركة آفاق</b>
            </p>
          </div>
          <div className="mini-table table-employees">
            <div>
              <Database size={14} />
              <code>employees</code>
              <span>100</span>
            </div>
            <p>
              <i>PK</i>
              <code>id</code>
              <b>1042</b>
            </p>
            <p>
              <code>name</code>
              <b>نورة القحطاني</b>
            </p>
            <p>
              <i>FK</i>
              <code>company_id</code>
              <b>1</b>
            </p>
            <p>
              <code>city</code>
              <b>الرياض</b>
            </p>
          </div>
          <div className="mini-table table-departments">
            <div>
              <Database size={14} />
              <code>departments</code>
              <span>05</span>
            </div>
            <p>
              <i>PK</i>
              <code>id</code>
              <b>3</b>
            </p>
            <p>
              <code>name</code>
              <b>الهندسة</b>
            </p>
          </div>
          <div className="verified-note">
            <ShieldCheck size={22} />
            <div>
              <strong>الدقة تبدأ من العلاقات.</strong>
              <small>رسم توضيحي · يتأكد رصد من كل مرجع</small>
            </div>
          </div>
          <div className="art-caption">BUILT ON CONTEXT. CONNECTED BY DESIGN.</div>
        </div>
      </section>
      <section className="service-section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">ثلاث طرق. نتيجة واحدة.</span>
            <h2>ابدأ من حيث وصل مشروعك.</h2>
          </div>
          <p>اختر المسار المناسب، ودع التفاصيل لرصد.</p>
        </div>
        <div className="service-cards">
          {services.map((s) => (
            <button
              className={'service-card service-' + s.key}
              key={s.key}
              onClick={() => onNavigate(s.key)}
            >
              <div className="card-top">
                <span className="service-icon">
                  <s.icon size={24} />
                </span>
                <span className="card-number">{s.n}</span>
              </div>
              <small>{s.en}</small>
              <h3>{s.title}</h3>
              <p>{s.description}</p>
              <div className="card-bottom">
                <span>{s.tag}</span>
                <ArrowUpLeft size={21} />
              </div>
            </button>
          ))}
        </div>
      </section>
      <section className="trust-strip">
        <div>
          <Layers size={22} />
          <span>
            <strong>البنية قبل السجلات</strong>
            <small>نفهم الجداول والعلاقات أولاً</small>
          </span>
        </div>
        <div>
          <ShieldCheck size={22} />
          <span>
            <strong>نتحقق من الناتج الفعلي</strong>
            <small>مفاتيح، حدود، وقواعد منطقية</small>
          </span>
        </div>
        <div>
          <Globe2 size={22} />
          <span>
            <strong>السياق السعودي حاضر</strong>
            <small>افتراضات واضحة، ومصادر عند توفرها</small>
          </span>
        </div>
      </section>
    </main>
  );
}
function Quick() {
  const [plan, setPlan] = useState<Plan | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [job, setJob] = useState(''),
    [name, setName] = useState('');
  async function upload(files: File[]) {
    setBusy(true);
    setError('');
    try {
      const form = new FormData();
      files.forEach((f) => form.append('file', f));
      const p = await api<Plan>('/schema/inspect', { method: 'POST', body: form });
      setPlan(p);
      setName(files[0]?.name ?? '');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function generate() {
    setBusy(true);
    setError('');
    try {
      const j = await post('/jobs/generate', plan);
      setJob(j.id);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      {error && <ErrorBox message={error} />}
      <div className="steps">
        <span className="active">01 رفع المخطط</span>
        <i />
        <span className={plan ? 'active' : ''}>02 مراجعة الخطة</span>
        <i />
        <span className={job ? 'active' : ''}>03 التوليد والتنزيل</span>
      </div>
      {!job && (
        <>
          {!plan ? (
            <section className="glass">
              <Upload accept=".sql,.prisma,.sqlite,.db,.zip" onFiles={upload} busy={busy} />
              <div className="upload-limits">
                <span>SQL / Prisma / SQLite حتى 4 MiB</span>
                <span>ZIP حتى 20 MiB · ملف مخطط واحد</span>
              </div>
              <Disclosure title="الصيغ المدعومة والحدود">
                <p>
                  CREATE TABLE مع الأنواع الشائعة والمفاتيح المركبة وCHECK الرقمي البسيط. نرفض
                  الصياغات غير المدعومة صراحة. SQLite يفحص المخطط فقط ولا ينفذ أوامره.
                </p>
                <p>
                  50 جدولاً، 50 حقلاً لكل جدول، 10000 صف لكل جدول، 20000 صف و250000 خلية إجمالاً،
                  والناتج حتى 8 MiB.
                </p>
              </Disclosure>
            </section>
          ) : (
            <>
              <div className="file-pill">
                <Braces size={17} />
                <bdi>{name}</bdi>
                <button className="text-button" onClick={() => setPlan(null)}>
                  تغيير الملف
                </button>
              </div>
              <PlanView plan={plan} onChange={setPlan} onGenerate={generate} busy={busy} />
            </>
          )}
        </>
      )}
      {job && <JobResult jobId={job} onClear={() => setJob('')} />}
    </>
  );
}
function Localization() {
  const [payload, setPayload] = useState<any>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [job, setJob] = useState(''),
    [economic, setEconomic] = useState('estimate'),
    [rate, setRate] = useState('');
  async function start(data: any) {
    setBusy(true);
    setError('');
    try {
      const j = await post('/jobs/localize', {
        ...data,
        options: { economic, ...(rate ? { currencyRate: Number(rate) } : {}) },
      });
      setJob(j.id);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function upload(files: File[]) {
    setBusy(true);
    setError('');
    try {
      const form = new FormData();
      files.forEach((f) => form.append('files', f));
      const result = await api('/localization/inspect', { method: 'POST', body: form });
      const p = { data: result.data, plan: result.plan };
      setPayload(p);
      await start(p);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      {error && <ErrorBox message={error} />}
      <div className="steps">
        <span className="active">01 رفع البيانات</span>
        <i />
        <span className={payload ? 'active' : ''}>02 التحليل والتوطين</span>
        <i />
        <span className={job ? 'active' : ''}>03 المقارنة والتنزيل</span>
      </div>
      {!job && (
        <section className="glass">
          <Upload
            accept=".csv,.json,.xlsx,.zip"
            multiple
            onFiles={upload}
            busy={busy}
            label="بياناتك جاهزة لتتحدث بسياق سعودي"
          />
          <div className="upload-limits">
            <span>حتى 10 ملفات · 10 MiB إجمالاً</span>
            <span>تبقى ملفاتك الأصلية كما هي</span>
          </div>
          <Disclosure title="إعدادات التوطين المتقدمة">
            <label>
              المبالغ الاقتصادية
              <select value={economic} onChange={(e) => setEconomic(e.target.value)}>
                <option value="estimate">تقديرات سعودية موسومة بوضوح</option>
                <option value="preserve">الحفاظ على المبالغ والعملات الأصلية</option>
              </select>
            </label>
            <label>
              سعر تحويل اختياري — بدلاً من تقدير السوق
              <input
                type="number"
                min="0.0001"
                step="any"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                placeholder="اتركه فارغاً للتقدير"
              />
            </label>
            <p>
              الرواتب تتأثر بالخبرة والمسمى. تقديرات الأسعار ليست مرجعاً سوقياً. لا تضاف VAT تلقائياً.
              الملفات ذات الفواتير المترابطة تحتاج قواعد مالية واضحة أو الحفاظ على المبالغ.
            </p>
          </Disclosure>
          {payload && (
            <button className="primary" disabled={busy} onClick={() => start(payload)}>
              {busy ? <Busy>جارٍ البدء</Busy> : 'توطين الملفات الحالية'}
            </button>
          )}
        </section>
      )}
      {job && (
        <>
          <JobResult jobId={job} onClear={() => setJob('')} />
          <Disclosure title="تعديل الخيارات وإعادة المعالجة">
            <label>
              المبالغ
              <select value={economic} onChange={(e) => setEconomic(e.target.value)}>
                <option value="estimate">تقدير سعودي</option>
                <option value="preserve">الحفاظ على المبالغ والعملات</option>
              </select>
            </label>
            <button className="secondary" disabled={busy} onClick={() => start(payload)}>
              إعادة المعالجة بالخيارات المحددة
            </button>
          </Disclosure>
        </>
      )}
    </>
  );
}
function Chat({ configured }: { configured?: boolean }) {
  const [domain, setDomain] = useState('employees'),
    [session, setSession] = useState<any>(null),
    [message, setMessage] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [plan, setPlan] = useState<Plan | null>(null),
    [job, setJob] = useState(''),
    [history, setHistory] = useState<any[]>([]);
  const epoch = useRef(0),
    end = useRef<HTMLDivElement>(null);
  const labels: Record<string, string> = {
    employees: 'الموظفون والشركات',
    commerce: 'التجارة الإلكترونية',
    university: 'الطلاب والجامعات',
  };
  async function newSession(d: string) {
    const ticket = ++epoch.current;
    setDomain(d);
    setSession(null);
    setPlan(null);
    setJob('');
    setMessage('');
    setError('');
    setBusy(true);
    try {
      const s = await post('/sessions', { domain: d });
      if (epoch.current !== ticket) return;
      setSession(s);
    } catch (e) {
      if (epoch.current === ticket) setError((e as Error).message);
    } finally {
      if (epoch.current === ticket) setBusy(false);
    }
  }
  useEffect(() => {
    newSession('employees');
    return () => {
      epoch.current++;
    };
  }, []);
  useEffect(() => {
    end.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }, [session?.messages.length]);
  async function send() {
    if (!message.trim() || !session) return;
    const ticket = epoch.current;
    setBusy(true);
    setError('');
    try {
      const s = await post('/sessions/' + session.id + '/messages', { message });
      if (ticket !== epoch.current) return;
      setSession(s);
      setPlan(s.plan ?? null);
      setMessage('');
    } catch (e) {
      if (ticket === epoch.current) setError((e as Error).message);
    } finally {
      if (ticket === epoch.current) setBusy(false);
    }
  }
  async function approve() {
    const ticket = epoch.current;
    setBusy(true);
    setError('');
    try {
      const updated = await api('/sessions/' + session.id + '/plan', {
        method: 'PUT',
        body: JSON.stringify(plan),
      });
      await post('/sessions/' + session.id + '/approve', { revision: updated.revision });
      const j = await post('/sessions/' + session.id + '/generate');
      if (ticket !== epoch.current) return;
      setSession(updated);
      setJob(j.id);
    } catch (e) {
      if (ticket === epoch.current) setError((e as Error).message);
    } finally {
      if (ticket === epoch.current) setBusy(false);
    }
  }
  async function resume(id: string) {
    const ticket = ++epoch.current;
    setBusy(true);
    setError('');
    try {
      const s = await api('/sessions/' + id);
      if (ticket !== epoch.current) return;
      setSession(s);
      setDomain(s.domain);
      setPlan(s.plan ?? null);
      setJob('');
      setHistory([]);
    } catch (e) {
      if (ticket === epoch.current) setError((e as Error).message);
    } finally {
      if (ticket === epoch.current) setBusy(false);
    }
  }
  return (
    <>
      <div className="chat-toolbar">
        <div className="domain-tabs">
          {Object.entries(labels).map(([key, label]) => (
            <button
              className={domain === key ? 'active' : ''}
              key={key}
              onClick={() => newSession(key)}
            >
              {label}
            </button>
          ))}
        </div>
        <div>
          <button className="text-button" onClick={() => newSession(domain)}>
            <Plus size={17} /> محادثة جديدة
          </button>
          <button
            className="text-button"
            onClick={() =>
              api<any[]>('/sessions')
                .then(setHistory)
                .catch((e) => setError(e.message))
            }
          >
            <History size={17} /> السابقة
          </button>
        </div>
      </div>
      {history.length > 0 && (
        <div className="glass history">
          {history.map((s) => (
            <button className="secondary" key={s.id} onClick={() => resume(s.id)}>
              {labels[s.domain]} · {s.id.slice(0, 8)}
            </button>
          ))}
        </div>
      )}
      {configured === false && (
        <div className="notice">
          المحادثة تحتاج مفتاح OpenAI. أضف OPENAI_API_KEY إلى إعدادات الخادم ثم أعد تشغيله. يمكنك
          استخدام التوليد السريع الآن.
        </div>
      )}
      {error && <ErrorBox message={error} />}
      <div className="chat-layout">
        <section className="glass chat-panel">
          <div className="chat-title">
            <span className="assistant-icon">
              <Sparkles size={20} />
            </span>
            <div>
              <strong>مساعد رصد</strong>
              <small>{labels[domain]} · محادثة مستقلة</small>
            </div>
            <span className="online-dot" />
          </div>
          <div className="messages" aria-live="polite">
            {session?.messages.map((m: any, i: number) => (
              <div key={i} className={'message ' + m.role}>
                {m.role === 'assistant' && <span className="avatar">ر</span>}
                <p>{m.content}</p>
              </div>
            ))}
            {!session && busy && <Busy>جارٍ إنشاء المحادثة</Busy>}
            {busy && session && <Busy>جارٍ إعداد الرد</Busy>}
            <div ref={end} />
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
          >
            <textarea
              aria-label="رسالتك لرصد"
              value={message}
              disabled={!session}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="مثلاً: شركة مقاولات، 100 موظف، وخمسة أقسام..."
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
            />
            <button
              className="send-button"
              aria-label="إرسال"
              disabled={busy || !message.trim() || !session}
            >
              <ArrowUp size={21} />
            </button>
          </form>
          <small className="chat-footnote">
            راجع الخطة قبل اعتمادها. التوليد يبدأ بموافقتك فقط.
          </small>
        </section>
        <aside className="glass chat-aside">
          <span className="eyebrow">من الحوار إلى البيانات</span>
          <h3>خطوة واحدة في كل مرة.</h3>
          <ol>
            <li>صف مشروعك وحجم البيانات</li>
            <li>راجع الجداول والعلاقات</li>
            <li>اعتمد الخطة ليبدأ التوليد</li>
            <li>افحص النتائج ونزّل ملفاتك</li>
          </ol>
          <div className="aside-note">
            <ShieldCheck size={22} />
            <p>لكل محادثة هوية مستقلة. تغيير المجال يبدأ حواراً جديداً.</p>
          </div>
        </aside>
      </div>
      {!job && plan && <PlanView plan={plan} onChange={setPlan} onGenerate={approve} busy={busy} />}
      {job && <JobResult jobId={job} onClear={() => setJob('')} />}
    </>
  );
}
createRoot(document.getElementById('root')!).render(<App />);
