import { useEffect, useRef, useState, type ReactNode } from 'react';
import {
  ArrowDownToLine,
  Check,
  ChevronDown,
  FileUp,
  LoaderCircle,
  ShieldCheck,
  X,
  Link2,
  Trash2,
  Square,
} from 'lucide-react';
import type { Plan } from '../shared/schema';
import { api, download, post } from './api';
export function ErrorBox({ message }: { message: string }) {
  return (
    <div className="error" role="alert">
      {message}
    </div>
  );
}
export function Busy({ children }: { children: ReactNode }) {
  return (
    <span className="busy">
      <LoaderCircle size={17} className="spin" />
      {children}
    </span>
  );
}
export function Upload({
  accept,
  onFiles,
  busy = false,
  multiple = false,
  label = 'اسحب ملفاتك إلى هنا',
}: {
  accept: string;
  onFiles: (files: File[]) => void;
  busy?: boolean;
  multiple?: boolean;
  label?: string;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  return (
    <div
      className={'dropzone ' + (over ? 'over' : '')}
      onDragOver={(e) => {
        e.preventDefault();
        setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setOver(false);
        if (!busy) onFiles([...e.dataTransfer.files]);
      }}
    >
      <div className="upload-symbol">
        <FileUp size={28} />
      </div>
      <h3>{busy ? <Busy>جارٍ فحص الملفات</Busy> : label}</h3>
      <p>أو اخترها من جهازك · تعالج الملفات بأمان</p>
      <button className="secondary" disabled={busy} onClick={() => input.current?.click()}>
        اختيار الملفات
      </button>
      <input
        ref={input}
        hidden
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={(e) => {
          if (e.target.files) onFiles([...e.target.files]);
          e.target.value = '';
        }}
      />
      <small dir="ltr">{accept.replaceAll(',', ' · ')}</small>
    </div>
  );
}
export function Disclosure({ title, children }: { title: string; children: ReactNode }) {
  return (
    <details className="disclosure">
      <summary>
        {title}
        <ChevronDown size={17} />
      </summary>
      <div>{children}</div>
    </details>
  );
}
export function PlanView({
  plan,
  onChange,
  onGenerate,
  busy,
  button = 'اعتماد الخطة وتوليد البيانات',
}: {
  plan: Plan;
  onChange: (p: Plan) => void;
  onGenerate: () => void;
  busy: boolean;
  button?: string;
}) {
  const [raw, setRaw] = useState('');
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState('');
  return (
    <section className="glass plan">
      <div className="section-heading">
        <div>
          <span className="eyebrow">مخطط البيانات</span>
          <h2>كل علاقة في مكانها.</h2>
        </div>
        <span className="tag">
          <Link2 size={14} />
          {plan.tables.length} جداول
        </span>
      </div>
      <div className="schema-grid">
        {plan.tables.map((t) => (
          <div className="schema-card" key={t.name}>
            <code>{t.name}</code>
            <label>
              عدد السجلات
              <input
                aria-label={'عدد ' + t.name}
                type="number"
                min="0"
                max="10000"
                value={t.count}
                onChange={(e) =>
                  onChange({
                    ...plan,
                    tables: plan.tables.map((x) =>
                      x.name === t.name ? { ...x, count: Number(e.target.value) } : x,
                    ),
                  })
                }
              />
            </label>
            <small>
              {t.fields.length} حقل · {t.foreignKeys.length} علاقات
            </small>
            <details>
              <summary>الحقول والمفاتيح</summary>
              <div className="field-list" dir="ltr">
                {t.fields.map((f) => (
                  <div key={f.name}>
                    <code>{f.name}</code>
                    <span>
                      {f.type}
                      {t.primaryKey.includes(f.name) ? ' · PK' : ''}
                      {t.foreignKeys.some((k) => k.columns.includes(f.name)) ? ' · FK' : ''}
                    </span>
                  </div>
                ))}
              </div>
              {t.foreignKeys.map((fk, i) => (
                <p key={i} dir="ltr">
                  <code>
                    {fk.columns.join(',')} → {fk.table}.{fk.references.join(',')}
                  </code>
                </p>
              ))}
            </details>
          </div>
        ))}
      </div>
      <Disclosure title={`الافتراضات والقواعد (${plan.assumptions.length + plan.rules.length})`}>
        <ul>
          {plan.assumptions.map((a, i) => (
            <li key={i}>{a}</li>
          ))}
        </ul>
        <pre dir="ltr">{JSON.stringify(plan.rules, null, 2)}</pre>
      </Disclosure>
      <Disclosure title="إعدادات متقدمة — تعديل الخطة والدلالات">
        <p>
          يمكن تحديد values أو semantic للحقول وتعديل القواعد. يتحقق الخادم من الخطة قبل التنفيذ.
        </p>
        <button
          className="text-button"
          onClick={() => {
            setRaw(JSON.stringify(plan, null, 2));
            setEditing(true);
          }}
        >
          فتح محرر JSON
        </button>
        {editing && (
          <>
            <textarea
              className="code-editor"
              dir="ltr"
              aria-label="خطة JSON"
              value={raw}
              onChange={(e) => setRaw(e.target.value)}
            />
            <button
              className="secondary"
              onClick={() => {
                try {
                  const p = JSON.parse(raw);
                  if (!p.tables || !Array.isArray(p.tables)) throw Error('الخطة تحتاج tables');
                  onChange(p);
                  setError('');
                  setEditing(false);
                } catch (e) {
                  setError((e as Error).message);
                }
              }}
            >
              تطبيق التعديلات
            </button>
          </>
        )}
        {error && <ErrorBox message={error} />}
      </Disclosure>
      <div className="plan-footer">
        <small>
          <ShieldCheck size={16} /> لن تصدّر بيانات تخفق في التحقق.
        </small>
        <button className="primary" disabled={busy} onClick={onGenerate}>
          {busy ? <Busy>جارٍ البدء</Busy> : button}
        </button>
      </div>
    </section>
  );
}
export function JobResult({ jobId, onClear }: { jobId: string; onClear: () => void }) {
  const [job, setJob] = useState<any>(null),
    [preview, setPreview] = useState<any>(null),
    [validation, setValidation] = useState<any>(null),
    [research, setResearch] = useState<any>(null),
    [error, setError] = useState(''),
    [table, setTable] = useState(''),
    [format, setFormat] = useState('json'),
    [dialect, setDialect] = useState('sqlite'),
    [downloading, setDownloading] = useState(false);
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    let alive = true;
    let timeout: ReturnType<typeof setTimeout>;
    setPreview(null);
    setError('');
    async function poll() {
      try {
        const j = await api('/jobs/' + jobId);
        if (!alive) return;
        setJob(j);
        if (j.status === 'complete') {
          const [p, v, r] = await Promise.all([
            api('/jobs/' + jobId + '/preview'),
            api('/jobs/' + jobId + '/validation'),
            api('/jobs/' + jobId + '/research'),
          ]);
          if (!alive) return;
          setPreview(p);
          setTable(p.tables[0]?.name ?? '');
          setValidation(v);
          setResearch(r);
        } else if (['pending', 'running'].includes(j.status)) timeout = setTimeout(poll, 900);
      } catch (e) {
        if (alive) setError((e as Error).message);
      }
    }
    poll();
    return () => {
      alive = false;
      clearTimeout(timeout);
    };
  }, [jobId, retry]);
  async function action(fn: () => Promise<any>) {
    try {
      setError('');
      await fn();
    } catch (e) {
      setError((e as Error).message);
    }
  }
  const selected = preview?.tables.find((t: any) => t.name === table);
  return (
    <section className="glass result">
      <div className="section-heading">
        <div>
          <span className="eyebrow">مساحة النتائج</span>
          <h2>
            {job?.status === 'complete'
              ? 'بيانات جاهزة. علاقات موثوقة.'
              : (job?.phase ?? 'جارٍ الاتصال')}
          </h2>
        </div>
        {job?.status === 'complete' && (
          <span className="tag success">
            <Check size={15} /> اجتازت التحقق
          </span>
        )}
      </div>
      {error && (
        <>
          <ErrorBox message={error} />
          <button className="secondary" onClick={() => setRetry((x) => x + 1)}>
            إعادة المحاولة
          </button>
        </>
      )}
      {job && ['pending', 'running'].includes(job.status) && (
        <>
          <div className="progress">
            <div style={{ width: job.progress + '%' }} />
          </div>
          <p>
            <Busy>
              {job.phase} · {job.progress}%
            </Busy>
          </p>
          <button
            className="text-button"
            onClick={() =>
              action(async () => {
                setJob(await post('/jobs/' + jobId + '/cancel'));
              })
            }
          >
            <Square size={14} /> إلغاء المهمة
          </button>
        </>
      )}
      {job?.status === 'failed' && (
        <>
          <ErrorBox message={job.error} />
          <button className="secondary" onClick={onClear}>
            العودة وتعديل المدخلات
          </button>
        </>
      )}
      {job?.status === 'cancelled' && (
        <>
          <p>ألغيت المهمة.</p>
          <button className="secondary" onClick={onClear}>
            العودة
          </button>
        </>
      )}
      {preview && (
        <>
          <div className="result-stats">
            <div>
              <strong>{validation.checkedRows.toLocaleString('ar-SA')}</strong>
              <span>سجل تم فحصه</span>
            </div>
            <div>
              <strong>{preview.tables.length}</strong>
              <span>جداول مترابطة</span>
            </div>
            <div>
              <strong>
                {((job.durationMs ?? 0) / 1000).toFixed(1)} <small>ث</small>
              </strong>
              <span>وقت المعالجة</span>
            </div>
            <div>
              <strong>
                {((job.outputBytes ?? 0) / 1024).toFixed(1)} <small>KB</small>
              </strong>
              <span>حجم البيانات</span>
            </div>
          </div>
          <div className="table-tabs">
            {preview.tables.map((t: any) => (
              <button
                key={t.name}
                className={table === t.name ? 'active' : ''}
                onClick={() => setTable(t.name)}
              >
                <bdi>{t.name}</bdi>
                <span>{t.count}</span>
              </button>
            ))}
          </div>
          {selected && (
            <>
              <div className="preview-note">
                معاينة أول {selected.rows.length} سجلاً من {selected.count} · جميع السجلات ضمن
                التنزيل
              </div>
              {selected.before && (
                <Disclosure title="مقارنة قبل التوطين وبعده">
                  <div className="comparison">
                    <div>
                      <h4>قبل</h4>
                      <DataTable rows={selected.before.slice(0, 5)} fields={selected.fields} />
                    </div>
                    <div>
                      <h4>بعد</h4>
                      <DataTable rows={selected.rows.slice(0, 5)} fields={selected.fields} />
                    </div>
                  </div>
                </Disclosure>
              )}
              <DataTable rows={selected.rows} fields={selected.fields} />
            </>
          )}
          <Disclosure title={`نتائج التحقق — ${validation.checks.length} فحوصات`}>
            <div className="check-list">
              {validation.checks.map((c: string) => (
                <span key={c}>
                  <ShieldCheck size={17} />
                  {c}
                </span>
              ))}
            </div>
            <p>
              {validation.checkedCells.toLocaleString('ar-SA')} خلية تم فحصها. لا توجد أخطاء حرجة.
            </p>
          </Disclosure>
          <Disclosure title={`المصادر المستخدمة (${research.evidence.length}) — عرض التفاصيل`}>
            <p className="muted">
              {research.warning ??
                (research.status === 'not-needed' ? 'لم تتطلب هذه الخطة بحثاً اقتصادياً.' : '')}
            </p>
            {research.evidence.map((e: any, i: number) => (
              <article className="evidence" key={i}>
                <a href={e.url} target="_blank" rel="noreferrer">
                  {e.title}
                </a>
                <p>{e.finding}</p>
                <small>
                  {e.field} · {e.applied ? 'مطبق' : 'للمراجعة؛ غير مطبق'}
                </small>
              </article>
            ))}
          </Disclosure>
          {preview.transforms && (
            <Disclosure title="التحويلات والافتراضات الاقتصادية">
              <ul>
                {preview.transforms.map((t: any, i: number) => (
                  <li key={i}>
                    <code>
                      {t.table}.{t.field}
                    </code>
                    : {t.method}
                  </li>
                ))}
              </ul>
              {preview.warnings?.map((w: string) => (
                <p key={w}>{w}</p>
              ))}
            </Disclosure>
          )}
          <div className="export-bar">
            <div>
              <strong>خذ بياناتك إلى مشروعك</strong>
              <small>ملفات UTF-8 تدعم العربية</small>
            </div>
            <label>
              الصيغة
              <select value={format} onChange={(e) => setFormat(e.target.value)}>
                <option value="json">JSON</option>
                <option value="csv">CSV + ZIP</option>
                <option value="xlsx">Excel XLSX</option>
                <option value="sql">SQL inserts</option>
              </select>
            </label>
            {format === 'sql' && (
              <label>
                قاعدة البيانات
                <select value={dialect} onChange={(e) => setDialect(e.target.value)}>
                  <option value="sqlite">SQLite</option>
                  <option value="postgres">PostgreSQL</option>
                  <option value="mysql">MySQL</option>
                </select>
              </label>
            )}
            <button
              className="primary"
              disabled={downloading}
              onClick={() =>
                action(async () => {
                  setDownloading(true);
                  try {
                    await download(jobId, format, dialect);
                  } finally {
                    setDownloading(false);
                  }
                })
              }
            >
              {downloading ? (
                <Busy>جارٍ التنزيل</Busy>
              ) : (
                <>
                  <ArrowDownToLine size={17} /> تنزيل البيانات
                </>
              )}
            </button>
          </div>
          <Disclosure title="تعليمات الاستيراد">
            <p>
              يحافظ JSON على الجداول والأنواع. يحتوي CSV ZIP على ملف لكل جدول وschema.json للعلاقات.
              استورد الآباء قبل الأبناء وفق العلاقات. SQL يضيف سجلات إلى مخطط مطابق وفارغ؛ خذ نسخة
              احتياطية أولاً.
            </p>
            <p>
              تنتهي صلاحية المهمة خلال 24 ساعة افتراضياً. SQL لقاعدة SQLite هو مسار التصدير المختبر
              آلياً.
            </p>
          </Disclosure>
          <button
            className="text-button danger"
            onClick={() =>
              action(async () => {
                await api('/jobs/' + jobId, { method: 'DELETE' });
                onClear();
              })
            }
          >
            <Trash2 size={15} /> حذف هذه البيانات المؤقتة
          </button>
        </>
      )}
    </section>
  );
}
function DataTable({ rows, fields }: { rows: any[]; fields: any[] }) {
  return (
    <div className="table-scroll">
      <table dir="ltr">
        <thead>
          <tr>
            {fields.map((f) => (
              <th key={f.name}>{f.name}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              {fields.map((f) => (
                <td key={f.name}>
                  {row[f.name] === null ? <span className="muted">NULL</span> : String(row[f.name])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export function Downloads() {
  const [jobs, setJobs] = useState<any[]>([]),
    [selected, setSelected] = useState(''),
    [error, setError] = useState(''),
    [loading, setLoading] = useState(true);
  function refresh() {
    setLoading(true);
    api<any[]>('/jobs')
      .then(setJobs)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }
  useEffect(refresh, []);
  return (
    <>
      {error && <ErrorBox message={error} />}
      <section className="glass">
        <div className="section-heading">
          <h2>نتائجك المؤقتة</h2>
          <button className="secondary" disabled={loading} onClick={refresh}>
            تحديث
          </button>
        </div>
        {loading ? (
          <Busy>جارٍ استرجاع المهام</Busy>
        ) : jobs.length === 0 ? (
          <p className="muted">
            لا توجد مهام محفوظة لهذا المتصفح. ابدأ بالتوليد أو التوطين لتظهر نتائجك هنا.
          </p>
        ) : (
          <div className="schema-grid">
            {jobs.map((j) => (
              <article className="schema-card" key={j.id}>
                <strong>{j.kind === 'localization' ? 'توطين سعودي' : 'توليد بيانات'}</strong>
                <p>
                  <small>
                    {j.plan.tables.length} جداول · {new Date(j.created).toLocaleString('ar-SA')}
                  </small>
                </p>
                <span className="tag">
                  {
                    {
                      complete: 'جاهزة',
                      failed: 'فشلت',
                      running: 'قيد التنفيذ',
                      pending: 'في الانتظار',
                      cancelled: 'ملغاة',
                    }[j.status as string]
                  }
                </span>
                <p>
                  <small>تنتهي: {new Date(j.expires).toLocaleString('ar-SA')}</small>
                </p>
                <button className="secondary" onClick={() => setSelected(j.id)}>
                  عرض النتيجة
                </button>
              </article>
            ))}
          </div>
        )}
      </section>
      {selected && (
        <JobResult
          key={selected}
          jobId={selected}
          onClear={() => {
            setSelected('');
            refresh();
          }}
        />
      )}
    </>
  );
}
