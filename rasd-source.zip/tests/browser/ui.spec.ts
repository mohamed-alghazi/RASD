import { test, expect } from '@playwright/test';
import path from 'node:path';
test('Arabic homepage and mobile navigation remain usable', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
  await expect(page.getByRole('heading', { name: /مشروعك يستحق/ })).toBeVisible();
  await page.screenshot({ path: 'test-results/home-desktop.png', fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: 'test-results/home-mobile.png', fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  );
  await page.getByRole('button', { name: 'القائمة', exact: true }).click();
  await page.locator('nav').getByRole('button', { name: 'التوليد السريع' }).click();
  await expect(page.getByRole('heading', { name: 'التوليد السريع', exact: true })).toBeVisible();
});
test('real SQL upload, plan review, generation, validation and downloaded JSON', async ({
  page,
}) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'لديّ مخطط جاهز' }).click();
  await page.locator('input[type=file]').setInputFiles(path.resolve('examples/contracting.sql'));
  await expect(page.getByText('كل علاقة في مكانها.')).toBeVisible();
  await page.getByLabel('عدد companies').fill('1');
  await page.getByLabel('عدد employees').fill('100');
  await page.getByRole('button', { name: 'اعتماد الخطة وتوليد البيانات' }).click();
  await expect(page.getByText('اجتازت التحقق', { exact: false })).toBeVisible({ timeout: 20000 });
  await page.getByText('نتائج التحقق —').click();
  await expect(page.getByText('المفاتيح الأساسية والفريدة', { exact: true })).toBeVisible();
  const pending = page.waitForEvent('download');
  await page.getByRole('button', { name: 'تنزيل البيانات' }).click();
  const download = await pending;
  const stream = await download.createReadStream();
  const chunks = [];
  for await (const chunk of stream!) chunks.push(chunk);
  const data = JSON.parse(Buffer.concat(chunks).toString());
  expect(data.companies).toHaveLength(1);
  expect(data.employees).toHaveLength(100);
  expect(new Set(data.employees.map((r: any) => r.company_id))).toEqual(new Set([1]));
  await page.screenshot({ path: 'test-results/quick-result.png', fullPage: true });
  await page.getByRole('button', { name: 'تنزيلاتي', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'نتائجك المؤقتة' })).toBeVisible();
  await page.getByRole('button', { name: 'عرض النتيجة', exact: true }).click();
  await expect(page.getByText('اجتازت التحقق', { exact: false })).toBeVisible();
});
test('localization automatically processes relational American data and preserves keys', async ({
  page,
}) => {
  await page.goto('/');
  await page.locator('nav').getByRole('button', { name: 'التوطين السعودي' }).click();
  await page.locator('input[type=file]').setInputFiles(path.resolve('examples/american.json'));
  await expect(page.getByText('اجتازت التحقق', { exact: false })).toBeVisible({ timeout: 20000 });
  await page.getByRole('button', { name: /employees/ }).click();
  await page.getByText('مقارنة قبل التوطين وبعده').click();
  await expect(page.getByText('John Smith', { exact: true })).toBeVisible();
  const pending = page.waitForEvent('download');
  await page.getByRole('button', { name: 'تنزيل البيانات' }).click();
  const download = await pending;
  const stream = await download.createReadStream();
  const chunks = [];
  for await (const chunk of stream!) chunks.push(chunk);
  const d = JSON.parse(Buffer.concat(chunks).toString());
  expect(d.employees[0].id).toBe(1);
  expect(d.employees[0].city).toBe('الرياض');
  expect(d.orders[0].total).toBe(d.payments[0].amount);
  await page.screenshot({ path: 'test-results/localization-result.png', fullPage: true });
});
test('domain switching creates isolated conversations and handles unavailable AI honestly', async ({
  page,
}) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'ابدأ بالمحادثة', exact: true }).click();
  await expect(page.getByText('ما نوع الشركة وكم موظفاً تحتاج؟')).toBeVisible();
  await page.getByRole('button', { name: 'الطلاب والجامعات', exact: true }).click();
  await expect(page.getByText('ما الجامعة وكم طالباً تريد توليده؟')).toBeVisible();
  await expect(page.getByText('ما نوع الشركة وكم موظفاً تحتاج؟')).toHaveCount(0);
  await page.getByRole('button', { name: 'التجارة الإلكترونية', exact: true }).click();
  await expect(page.getByText('ما نوع المتجر وكم عميلاً تحتاج؟')).toBeVisible();
  const health = await page.request.get('/api/health');
  if (!(await health.json()).aiConfigured) {
    await page.getByLabel('رسالتك لرصد').fill('100');
    await page.getByRole('button', { name: 'إرسال', exact: true }).click();
    await expect(page.getByRole('alert')).toContainText('OPENAI_API_KEY');
    await expect(page.getByLabel('رسالتك لرصد')).toHaveValue('100');
  }
  await page.screenshot({ path: 'test-results/chat.png', fullPage: true });
});
