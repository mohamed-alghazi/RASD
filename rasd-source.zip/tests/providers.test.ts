import { afterEach, describe, it, expect, vi } from 'vitest';
import { aiTurn, type ChatState } from '../server/ai';
import { domainPlan } from '../server/catalog';
const oldKey = process.env.OPENAI_API_KEY;
afterEach(() => {
  vi.unstubAllGlobals();
  if (oldKey) process.env.OPENAI_API_KEY = oldKey;
  else delete process.env.OPENAI_API_KEY;
});
const state: ChatState = {
  domain: 'employees',
  messages: [{ role: 'assistant', content: 'كم موظفاً؟' }],
  requirements: 'شركة مقاولات',
  approved: false,
  revision: 0,
};
describe('real provider adapter contract — simulated HTTP responses, no live credentials', () => {
  it('sends contextual Arabic history with strict structured outputs and validates returned plan', async () => {
    process.env.OPENAI_API_KEY = 'test-only';
    const fn = vi.fn(async (url: any, options: any) => {
      const body = JSON.parse(options.body);
      expect(body.messages.at(-1).content).toBe('100');
      expect(body.messages[1].content).toBe('كم موظفاً؟');
      expect(body.response_format.json_schema.strict).toBe(true);
      return new Response(
        JSON.stringify({
          choices: [
            {
              message: {
                content: JSON.stringify({
                  reply: 'خطة للمراجعة',
                  requirements: 'شركة مقاولات 100 موظف',
                  ready: true,
                  count: 100,
                  planJson: JSON.stringify(domainPlan('employees')),
                }),
              },
            },
          ],
        }),
      );
    });
    vi.stubGlobal('fetch', fn);
    const result = await aiTurn(state, '100');
    expect(result.plan?.tables.find((t) => t.name === 'employees')?.count).toBe(100);
    expect(fn).toHaveBeenCalledOnce();
  });
  it('malformed model output is retried exactly once and cannot corrupt state', async () => {
    process.env.OPENAI_API_KEY = 'test-only';
    const before = structuredClone(state);
    const fn = vi.fn(
      async () =>
        new Response(
          JSON.stringify({ choices: [{ message: { content: '{"execute":"DROP TABLE users"}' } }] }),
        ),
    );
    vi.stubGlobal('fetch', fn);
    await expect(aiTurn(state, 'نعم')).rejects.toMatchObject({ code: 'AI_INVALID_OUTPUT' });
    expect(fn).toHaveBeenCalledTimes(2);
    expect(state).toEqual(before);
  });
  it('rejects a valid-shaped plan from a different domain', async () => {
    process.env.OPENAI_API_KEY = 'test-only';
    vi.stubGlobal(
      'fetch',
      async () =>
        new Response(
          JSON.stringify({
            choices: [
              {
                message: {
                  content: JSON.stringify({
                    reply: 'خطة',
                    requirements: 'test',
                    ready: true,
                    count: 100,
                    planJson: JSON.stringify(domainPlan('commerce')),
                  }),
                },
              },
            ],
          }),
        ),
    );
    await expect(aiTurn(state, '100')).rejects.toMatchObject({ code: 'AI_INVALID_OUTPUT' });
  });
  it('provider authentication errors return a controlled actionable error', async () => {
    process.env.OPENAI_API_KEY = 'test-only';
    vi.stubGlobal('fetch', async () => new Response('{}', { status: 401 }));
    await expect(aiTurn(state, '100')).rejects.toMatchObject({
      code: 'AI_PROVIDER_ERROR',
      status: 502,
    });
  });
});
