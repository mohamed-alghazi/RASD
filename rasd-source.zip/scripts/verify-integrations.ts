import { loadEnvironment, credentialStatus } from '../server/config';
import { aiTurn, type ChatState } from '../server/ai';
import { research } from '../server/research';
import { generate } from '../server/generator';
import { validate } from '../server/validation';
loadEnvironment();
const configured = credentialStatus();
const status: Record<string, unknown> = {
  configured,
  ai: 'skipped — OPENAI_API_KEY missing',
  research: 'skipped — TAVILY_API_KEY missing',
};
if (configured.OPENAI_API_KEY) {
  try {
    const state: ChatState = {
      domain: 'employees',
      messages: [{ role: 'assistant', content: 'ما نوع الشركة وكم موظفاً تحتاج؟' }],
      requirements: '',
      approved: false,
      revision: 0,
    };
    const { result, plan } = await aiTurn(
      state,
      'شركة مقاولات أحتاج 100 موظف وخمسة أقسام و30% خبرتهم أكثر من خمس سنوات',
    );
    status.ai = plan
      ? {
          providerResponded: true,
          planValid: true,
          dataValid: validate(plan, generate(plan)).valid,
        }
      : { providerResponded: true, planValid: false, clarificationRequested: !result.ready };
  } catch (e) {
    status.ai = {
      verified: false,
      code: e && typeof e === 'object' && 'code' in e ? String(e.code) : 'VERIFICATION_FAILED',
    };
  }
}
if (configured.TAVILY_API_KEY) {
  const result = await research(
    'salary',
    'employees.salary',
    'software engineer salary Saudi Arabia',
  );
  status.research = {
    status: result.status,
    relevantSources: result.evidence.length,
    appliedSources: result.evidence.filter((e) => e.applied).length,
  };
}
console.log(JSON.stringify(status, null, 2));
